# DR DB KUSH 2.0 — Daily Competitor Intel Dashboard

Automatically pulls YouTube competitor data via vidIQ + Claude every morning at **7:00 AM Mountain Time** and publishes a live HTML report to GitHub Pages.

---

## ⚡ Setup (5 steps, ~10 minutes)

### 1. Create a GitHub account & new repo
- Go to [github.com](https://github.com) and sign up (free)
- Click **New repository**
- Name it: `dr-db-kush-intel`
- Set to **Public** (required for free GitHub Pages)
- Click **Create repository**

---

### 2. Upload this project
Drag and drop the entire folder into GitHub, OR use the GitHub web editor:
- Upload `.github/workflows/daily-report.yml`
- Upload `scripts/generate_report.py`
- Upload `docs/index.html`

---

### 3. Add your API keys as GitHub Secrets
In your repo → **Settings → Secrets and variables → Actions → New repository secret**

Add these two secrets:

| Secret name | Where to get it |
|---|---|
| `ANTHROPIC_API_KEY` | [console.anthropic.com](https://console.anthropic.com) → API Keys |
| `VIDIQ_API_KEY` | [vidiq.com](https://vidiq.com) → Account → API / MCP Settings |

---

### 4. Enable GitHub Pages
In your repo → **Settings → Pages**
- Source: **Deploy from a branch**
- Branch: `gh-pages` / `/ (root)`
- Click **Save**

Your dashboard URL will be:
`https://YOUR-GITHUB-USERNAME.github.io/dr-db-kush-intel/`

---

### 5. Test it manually
- Go to your repo → **Actions** tab
- Click **Daily Competitor Intel Report**
- Click **Run workflow** → **Run workflow**
- Watch it run (~60 seconds)
- Visit your GitHub Pages URL — your first report is live!

---

## ⏰ Schedule
The cron runs at `0 13 * * *` UTC = **7:00 AM Mountain Standard Time**.

> **Note:** Denver switches to MDT (UTC-6) in summer. Update the cron to `0 12 * * *` from March–November for exact 7 AM MDT.

Or just use the manual trigger in Actions anytime.

---

## 📁 File structure
```
.github/
  workflows/
    daily-report.yml     ← GitHub Actions cron job
scripts/
  generate_report.py     ← Calls Claude + vidIQ, renders HTML
docs/
  index.html             ← Latest report (auto-updated daily)
  archive/
    YYYY-MM-DD.html      ← Past reports kept forever
    YYYY-MM-DD.json      ← Raw JSON data for each day
```

---

## 💡 Customizing competitors
Edit `COMPETITOR_IDS` in `scripts/generate_report.py` to add/remove channels.
Accepts YouTube channel IDs (`UC...`) or handles (`@channelname`).
